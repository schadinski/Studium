package Bank;

public interface IPerson {
	public String getName();
	public void setName(String newName);
	public Date getDateOfBirth();
	public void setDateOfBirth(Date newDateOfBirth);
}
